def find(num1, num2, num3):
    if num1 == num2:
        return 4
    elif num1 == num3:
        return 2
    else:
        return 1

    pass
