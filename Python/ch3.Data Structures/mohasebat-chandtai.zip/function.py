def calc(a: list) -> tuple:
    n=len(a)
    
    max_num = a[0]
    for i in range(1, n):
        if a[i] > max_num:
            max_num = a[i]

    # محاسبه میانگین
    avg = sum(a) / n

    a.sort()
    # برای چک کردن تعداد اعضای آرایه، به صورت جفت و فرد دو حالت در نظر گرفته شده است.
    if (n % 2 == 0):
        median1 = a[n//2]
        median2 = a[n//2 - 1]
        median = (median1 + median2)/2
    else:
            median = a[n//2]
            
    return (avg,median,max_num)