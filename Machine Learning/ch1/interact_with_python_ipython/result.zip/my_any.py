# coding: utf-8
def my_any(x):
    for i in x:
        if i:
            return True
    return False
